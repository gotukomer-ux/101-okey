#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter SDK bulunamadı. https://docs.flutter.dev/get-started/install adresinden Flutter'ı kurun." >&2
  exit 1
fi

flutter create --platforms=android --org com.example --project-name classic_101_okey "$TMP/scaffold"
rm -rf "$ROOT/android"
cp -R "$TMP/scaffold/android" "$ROOT/android"
cp "$ROOT/android_template/app/src/main/AndroidManifest.xml" "$ROOT/android/app/src/main/AndroidManifest.xml"
mkdir -p "$ROOT/android/app/src/main/kotlin/com/example/classic_101_okey"
cp "$ROOT/android_template/app/src/main/kotlin/com/example/classic_101_okey/MainActivity.kt" \
  "$ROOT/android/app/src/main/kotlin/com/example/classic_101_okey/MainActivity.kt"
echo "Android platform klasörü oluşturuldu ve Bluetooth/Wi-Fi entegrasyonu eklendi."
echo "Sonraki adım: flutter pub get && flutter test && flutter build apk --debug"
