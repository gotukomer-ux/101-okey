package com.example.classic_101_okey

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread

class MainActivity : FlutterActivity() {
    companion object {
        private const val METHOD_CHANNEL = "classic_101_okey/bluetooth"
        private const val EVENT_CHANNEL = "classic_101_okey/bluetooth_events"
        private const val PERMISSION_CHANNEL = "classic_101_okey/platform_permissions"
        private const val REQUEST_CONNECT_PERMISSION = 7412
        private const val REQUEST_LOCAL_NETWORK_PERMISSION = 7413
        private val SERVICE_UUID: UUID = UUID.fromString("d2f3a620-4b3c-4d1e-9c5a-1010a0b0c0d1")
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var eventSink: EventChannel.EventSink? = null
    private var pendingPermissionResult: MethodChannel.Result? = null
    private var pendingPermissionAction: (() -> Unit)? = null
    private var pendingPermissionCode: Int? = null
    private var serverSocket: BluetoothServerSocket? = null
    private var clientSocket: BluetoothSocket? = null
    private val peerSockets = ConcurrentHashMap<String, BluetoothSocket>()
    @Volatile private var isHost = false
    @Volatile private var stopping = false

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, METHOD_CHANNEL)
            .setMethodCallHandler { call, result -> handleMethod(call, result) }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, PERMISSION_CHANNEL)
            .setMethodCallHandler { call, result ->
                if (call.method == "ensureLocalNetworkPermission") {
                    withLocalNetworkPermission(result) { result.success(true) }
                } else {
                    result.notImplemented()
                }
            }
        EventChannel(flutterEngine.dartExecutor.binaryMessenger, EVENT_CHANNEL)
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                    eventSink = events
                }
                override fun onCancel(arguments: Any?) {
                    eventSink = null
                }
            })
    }

    private fun handleMethod(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "pairedDevices" -> withConnectPermission(result) {
                val adapter = bluetoothAdapter()
                if (adapter == null) {
                    result.error("NO_BLUETOOTH", "Bu telefonda Bluetooth bulunamadı.", null)
                } else {
                    val devices = adapter.bondedDevices.map { device ->
                        mapOf("name" to (device.name ?: "İsimsiz cihaz"), "address" to device.address)
                    }.sortedBy { it["name"].toString().lowercase() }
                    result.success(devices)
                }
            }
            "startServer" -> withConnectPermission(result) {
                val adapter = bluetoothAdapter()
                if (adapter == null) {
                    result.error("NO_BLUETOOTH", "Bu telefonda Bluetooth bulunamadı.", null)
                } else if (!adapter.isEnabled) {
                    result.error("BT_DISABLED", "Bluetooth kapalı. Telefon ayarlarından Bluetooth'u açın.", null)
                } else {
                    try {
                        stopSockets()
                        isHost = true
                        stopping = false
                        serverSocket = adapter.listenUsingRfcommWithServiceRecord("101 Okey", SERVICE_UUID)
                        val localName = adapter.name ?: "Bluetooth masası"
                        thread(name = "okey-bt-accept") { acceptLoop() }
                        result.success(localName)
                    } catch (error: Exception) {
                        result.error("BT_SERVER_FAILED", error.message ?: "Bluetooth masası açılamadı.", null)
                    }
                }
            }
            "connect" -> withConnectPermission(result) {
                val adapter = bluetoothAdapter()
                val address = call.argument<String>("address")
                if (adapter == null) {
                    result.error("NO_BLUETOOTH", "Bu telefonda Bluetooth bulunamadı.", null)
                } else if (!adapter.isEnabled) {
                    result.error("BT_DISABLED", "Bluetooth kapalı. Telefon ayarlarından Bluetooth'u açın.", null)
                } else if (address.isNullOrBlank()) {
                    result.error("BAD_ADDRESS", "Bluetooth cihaz adresi eksik.", null)
                } else {
                    stopping = false
                    isHost = false
                    thread(name = "okey-bt-connect") {
                        try {
                            val device = adapter.getRemoteDevice(address)
                            val socket = device.createRfcommSocketToServiceRecord(SERVICE_UUID)
                            socket.connect()
                            clientSocket = socket
                            emit(mapOf("type" to "connected", "peerId" to "bt-server"))
                            readLoop(socket, "bt-server")
                        } catch (error: Exception) {
                            emit(mapOf("type" to "error", "message" to (error.message ?: "Bluetooth bağlantısı başarısız.")))
                            try { clientSocket?.close() } catch (_: Exception) {}
                            clientSocket = null
                        }
                    }
                    result.success(true)
                }
            }
            "sendMessage" -> {
                val data = call.argument<String>("data")
                val peerId = call.argument<String>("peerId")
                val broadcast = call.argument<Boolean>("broadcast") ?: false
                if (data.isNullOrEmpty()) {
                    result.error("EMPTY_MESSAGE", "Gönderilecek mesaj boş.", null)
                } else {
                    try {
                        if (isHost) {
                            if (broadcast) {
                                peerSockets.values.toList().forEach { writeLine(it, data) }
                            } else if (peerId != null) {
                                val socket = peerSockets[peerId]
                                    ?: throw IllegalStateException("Oyuncu Bluetooth bağlantısı bulunamadı.")
                                writeLine(socket, data)
                            } else {
                                throw IllegalStateException("Bluetooth alıcısı belirtilmedi.")
                            }
                        } else {
                            val socket = clientSocket ?: throw IllegalStateException("Bluetooth sunucusuna bağlı değil.")
                            writeLine(socket, data)
                        }
                        result.success(true)
                    } catch (error: Exception) {
                        result.error("BT_SEND_FAILED", error.message ?: "Bluetooth mesajı gönderilemedi.", null)
                    }
                }
            }
            "disconnectPeer" -> {
                val peerId = call.argument<String>("peerId")
                if (!isHost || peerId.isNullOrBlank()) {
                    result.error("BAD_PEER", "Bluetooth oyuncu bağlantısı geçersiz.", null)
                } else {
                    val socket = peerSockets.remove(peerId)
                    if (socket == null) {
                        result.success(false)
                    } else {
                        try { socket.close() } catch (_: Exception) {}
                        result.success(true)
                    }
                }
            }
            "stop" -> {
                stopSockets()
                result.success(true)
            }
            "openSettings" -> {
                try {
                    startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                    result.success(true)
                } catch (error: Exception) {
                    result.error("SETTINGS_FAILED", error.message, null)
                }
            }
            else -> result.notImplemented()
        }
    }

    private fun withConnectPermission(result: MethodChannel.Result, action: () -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            action()
            return
        }
        if (pendingPermissionResult != null) {
            result.error("PERMISSION_BUSY", "Bluetooth izin isteği zaten açık.", null)
            return
        }
        pendingPermissionResult = result
        pendingPermissionAction = action
        pendingPermissionCode = REQUEST_CONNECT_PERMISSION
        requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), REQUEST_CONNECT_PERMISSION)
    }

    private fun withLocalNetworkPermission(result: MethodChannel.Result, action: () -> Unit) {
        // ACCESS_LOCAL_NETWORK is enforced for apps targeting API 37+ on Android 17+.
        if (Build.VERSION.SDK_INT < 37 || applicationInfo.targetSdkVersion < 37 ||
            checkSelfPermission("android.permission.ACCESS_LOCAL_NETWORK") == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            action()
            return
        }
        if (pendingPermissionResult != null) {
            result.error("PERMISSION_BUSY", "Başka bir izin isteği zaten açık.", null)
            return
        }
        pendingPermissionResult = result
        pendingPermissionAction = action
        pendingPermissionCode = REQUEST_LOCAL_NETWORK_PERMISSION
        requestPermissions(arrayOf("android.permission.ACCESS_LOCAL_NETWORK"), REQUEST_LOCAL_NETWORK_PERMISSION)
    }

    @Deprecated("Deprecated in Android API; retained for Flutter activity permission callback")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CONNECT_PERMISSION || requestCode == REQUEST_LOCAL_NETWORK_PERMISSION) {
            val result = pendingPermissionResult
            val action = pendingPermissionAction
            val permissionCode = pendingPermissionCode
            pendingPermissionResult = null
            pendingPermissionAction = null
            pendingPermissionCode = null
            if (grantResults.isNotEmpty() && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                action?.invoke()
            } else {
                val message = if (permissionCode == REQUEST_CONNECT_PERMISSION)
                    "Bluetooth için Yakındaki cihazlar izni gerekli."
                else
                    "Aynı Wi-Fi ağı üzerinden bağlantı için Yerel ağ izni gerekli."
                result?.error("PERMISSION_DENIED", message, null)
            }
        }
    }

    private fun bluetoothAdapter(): BluetoothAdapter? {
        val manager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        return manager.adapter
    }

    private fun acceptLoop() {
        while (!stopping) {
            try {
                val socket = serverSocket?.accept() ?: break
                if (peerSockets.size >= 3) {
                    try { writeLine(socket, "{\"type\":\"room_full\"}") } catch (_: Exception) {}
                    try { socket.close() } catch (_: Exception) {}
                    continue
                }
                val peerId = socket.remoteDevice.address
                peerSockets[peerId] = socket
                emit(mapOf("type" to "peer_joined", "peerId" to peerId, "name" to (socket.remoteDevice.name ?: "Oyuncu")))
                thread(name = "okey-bt-read-$peerId") { readLoop(socket, peerId) }
            } catch (error: Exception) {
                if (!stopping) emit(mapOf("type" to "error", "message" to (error.message ?: "Bluetooth kabul hatası.")))
                break
            }
        }
    }

    private fun readLoop(socket: BluetoothSocket, peerId: String) {
        try {
            val reader = BufferedReader(InputStreamReader(socket.inputStream, StandardCharsets.UTF_8))
            while (!stopping) {
                val line = reader.readLine() ?: break
                emit(mapOf("type" to "message", "peerId" to peerId, "data" to line))
            }
        } catch (error: Exception) {
            if (!stopping) emit(mapOf("type" to "error", "peerId" to peerId, "message" to (error.message ?: "Bluetooth veri okuma hatası.")))
        } finally {
            if (peerId == "bt-server") {
                clientSocket = null
                emit(mapOf("type" to "disconnected", "peerId" to peerId))
            } else {
                peerSockets.remove(peerId)
                emit(mapOf("type" to "peer_left", "peerId" to peerId))
            }
            try { socket.close() } catch (_: Exception) {}
        }
    }

    private fun writeLine(socket: BluetoothSocket, data: String) {
        synchronized(socket) {
            socket.outputStream.write((data + "\n").toByteArray(StandardCharsets.UTF_8))
            socket.outputStream.flush()
        }
    }

    private fun emit(event: Map<String, Any?>) {
        mainHandler.post { eventSink?.success(event) }
    }

    private fun stopSockets() {
        stopping = true
        try { serverSocket?.close() } catch (_: Exception) {}
        serverSocket = null
        try { clientSocket?.close() } catch (_: Exception) {}
        clientSocket = null
        peerSockets.values.toList().forEach { try { it.close() } catch (_: Exception) {} }
        peerSockets.clear()
        isHost = false
    }

    override fun onDestroy() {
        stopSockets()
        super.onDestroy()
    }
}
