import 'dart:async';
import 'dart:convert';

import 'package:flutter/services.dart';

import 'multiplayer_transport.dart';
import 'transport_event.dart';

/// Android Bluetooth Classic RFCOMM transport. Devices must first be paired
/// in Android Bluetooth settings; the app then connects to a paired phone.
class BluetoothTransport implements MultiplayerTransport, DisposableMultiplayerTransport {
  static const MethodChannel _methods =
      MethodChannel('classic_101_okey/bluetooth');
  static const EventChannel _eventChannel =
      EventChannel('classic_101_okey/bluetooth_events');

  StreamSubscription<dynamic>? _subscription;
  final StreamController<TransportEvent> _events =
      StreamController<TransportEvent>.broadcast();
  bool _isHost = false;

  @override
  Stream<TransportEvent> get events => _events.stream;

  void _ensureListening() {
    _subscription ??= _eventChannel.receiveBroadcastStream().listen(
      (dynamic raw) {
        if (raw is! Map) return;
        final event = Map<String, dynamic>.from(raw);
        final type = event['type'] as String? ?? 'error';
        switch (type) {
          case 'connected':
          case 'peer_joined':
            _emit(TransportEvent(
                type: TransportEventType.connected,
                peerId: event['peerId'] as String?));
            break;
          case 'disconnected':
          case 'peer_left':
            _emit(TransportEvent(
                type: TransportEventType.disconnected,
                peerId: event['peerId'] as String?));
            break;
          case 'message':
            try {
              final decoded = jsonDecode(event['data'] as String);
              if (decoded is Map<String, dynamic>) {
                _emit(TransportEvent(
                    type: TransportEventType.message,
                    peerId: event['peerId'] as String?,
                    data: decoded));
              }
            } on FormatException catch (error) {
              _emit(TransportEvent(
                  type: TransportEventType.error,
                  peerId: event['peerId'] as String?,
                  message: 'Bluetooth mesajı okunamadı: ${error.message}'));
            }
            break;
          default:
            _emit(TransportEvent(
                type: TransportEventType.error,
                message: event['message'] as String? ?? 'Bluetooth hatası'));
        }
      },
      onError: (Object error) => _emit(TransportEvent(
          type: TransportEventType.error,
          message: 'Bluetooth olay kanalı hatası: $error')),
    );
  }

  @override
  Future<String> host() async {
    _ensureListening();
    _isHost = true;
    final result = await _methods.invokeMethod<String>('startServer');
    return result ?? 'Bluetooth masası';
  }

  @override
  Future<void> join(String target) async {
    _ensureListening();
    _isHost = false;
    await _methods.invokeMethod<void>('connect', {'address': target});
  }

  @override
  Future<void> send(Map<String, dynamic> message, {String? peerId}) async {
    await _methods.invokeMethod<void>('sendMessage', {
      'data': jsonEncode(message),
      if (peerId != null) 'peerId': peerId,
      'broadcast': peerId == null && _isHost,
    });
  }


  @override
  Future<void> disconnectPeer(String peerId) async {
    await _methods.invokeMethod<void>('disconnectPeer', {'peerId': peerId});
  }

  @override
  Future<void> close() async {
    await _methods.invokeMethod<void>('stop');
    _isHost = false;
  }

  @override
  Future<List<PairedBluetoothDevice>> pairedBluetoothDevices() async {
    final result = await _methods.invokeListMethod<dynamic>('pairedDevices');
    return (result ?? const [])
        .whereType<Map>()
        .map((item) => PairedBluetoothDevice(
              name: item['name'] as String? ?? 'İsimsiz cihaz',
              address: item['address'] as String? ?? '',
            ))
        .where((device) => device.address.isNotEmpty)
        .toList();
  }

  @override
  Future<void> openBluetoothSettings() async {
    await _methods.invokeMethod<void>('openSettings');
  }

  void _emit(TransportEvent event) {
    if (!_events.isClosed) _events.add(event);
  }

  @override
  Future<void> disposeTransport() async {
    await close();
    await _subscription?.cancel();
    await _events.close();
  }
}
