enum TransportEventType { connected, disconnected, message, error }

class TransportEvent {
  const TransportEvent({
    required this.type,
    this.peerId,
    this.data,
    this.message,
  });

  final TransportEventType type;
  final String? peerId;
  final Map<String, dynamic>? data;
  final String? message;
}

class PairedBluetoothDevice {
  const PairedBluetoothDevice({required this.name, required this.address});

  final String name;
  final String address;
}
