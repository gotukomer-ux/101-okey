class RoomPlayer {
  const RoomPlayer({
    required this.id,
    required this.name,
    required this.seat,
    required this.isHost,
  });

  final String id;
  final String name;
  final int seat;
  final bool isHost;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'seat': seat,
        'isHost': isHost,
      };

  factory RoomPlayer.fromJson(Map<String, dynamic> json) => RoomPlayer(
        id: json['id'] as String,
        name: json['name'] as String,
        seat: json['seat'] as int,
        isHost: json['isHost'] as bool? ?? false,
      );
}

class RoomSnapshot {
  const RoomSnapshot({
    required this.players,
    required this.started,
  });

  final List<RoomPlayer> players;
  final bool started;

  int get occupiedSeats => players.length;
  bool get isFull => players.length == 4;

  Map<String, dynamic> toJson() => {
        'players': players.map((player) => player.toJson()).toList(),
        'started': started,
      };

  factory RoomSnapshot.fromJson(Map<String, dynamic> json) {
    final rawPlayers = json['players'];
    if (rawPlayers is! List) {
      throw const FormatException('Oda oyuncu listesi geçersiz.');
    }
    if (rawPlayers.any((item) => item is! Map)) {
      throw const FormatException('Oda oyuncu listesinde geçersiz kayıt var.');
    }
    final players = rawPlayers
        .map((item) => RoomPlayer.fromJson(Map<String, dynamic>.from(item as Map)))
        .toList();
    final seats = players.map((p) => p.seat).toSet();
    final ids = players.map((p) => p.id).toSet();
    if (players.length > 4 ||
        seats.length != players.length ||
        ids.length != players.length ||
        players.any((p) => p.seat < 0 || p.seat > 3 || p.id.isEmpty)) {
      throw const FormatException('Oda koltuk veya oyuncu bilgisi geçersiz.');
    }
    return RoomSnapshot(
      players: players..sort((a, b) => a.seat.compareTo(b.seat)),
      started: json['started'] as bool? ?? false,
    );
  }
}

class JoinOutcome {
  const JoinOutcome.accepted(this.snapshot)
      : accepted = true,
        reason = null,
        player = null;
  const JoinOutcome.rejected(this.reason)
      : accepted = false,
        snapshot = null,
        player = null;

  final bool accepted;
  final String? reason;
  final RoomSnapshot? snapshot;
  final RoomPlayer? player;
}

/// Host-authoritative seat registry: the host occupies seat 0 and may admit
/// at most three remote players. This class is independent of networking.
class RoomRegistry {
  RoomRegistry({required String hostId, required String hostName})
      : _players = [
          RoomPlayer(
              id: hostId,
              name: RoomRegistry._normaliseName(hostName),
              seat: 0,
              isHost: true)
        ];

  final List<RoomPlayer> _players;
  final Map<String, String> _playerByPeer = {};
  bool _started = false;

  RoomSnapshot get snapshot => RoomSnapshot(
      players: List.unmodifiable(_players), started: _started);

  JoinOutcome join({
    required String playerId,
    required String playerName,
    required String peerId,
  }) {
    final id = playerId.trim();
    if (id.isEmpty || id.length > 80 || peerId.isEmpty) {
      return const JoinOutcome.rejected('Oyuncu kimliği geçersiz.');
    }
    if (_players.any((player) => player.id == id) || _playerByPeer.containsKey(peerId)) {
      return const JoinOutcome.rejected('Bu oyuncu veya bağlantı zaten masada.');
    }
    if (_started) return const JoinOutcome.rejected('Oyun başlamış; yeni oyuncu alınamaz.');
    if (_players.length >= 4) return const JoinOutcome.rejected('Masa dolu.');

    final occupied = _players.map((player) => player.seat).toSet();
    final seat = List<int>.generate(4, (index) => index)
        .firstWhere((candidate) => !occupied.contains(candidate));
    final player = RoomPlayer(
      id: id,
      name: _normaliseName(playerName),
      seat: seat,
      isHost: false,
    );
    _players.add(player);
    _playerByPeer[peerId] = id;
    return JoinOutcome.accepted(snapshot);
  }

  bool removePeer(String peerId) {
    final playerId = _playerByPeer.remove(peerId);
    if (playerId == null) return false;
    _players.removeWhere((player) => player.id == playerId && !player.isHost);
    return true;
  }

  RoomPlayer? playerForPeer(String peerId) {
    final playerId = _playerByPeer[peerId];
    if (playerId == null) return null;
    for (final player in _players) {
      if (player.id == playerId) return player;
    }
    return null;
  }

  String? peerForSeat(int seat) {
    final matches = _players.where((candidate) => candidate.seat == seat).toList();
    if (matches.isEmpty || matches.first.isHost) return null;
    final player = matches.first;
    for (final entry in _playerByPeer.entries) {
      if (entry.value == player.id) return entry.key;
    }
    return null;
  }

  void start() {
    if (_players.length != 4) {
      throw StateError('Masa başlatmak için dört oyuncu da oturmalı.');
    }
    _started = true;
  }

  static String _normaliseName(String value) {
    final name = value.trim().replaceAll(RegExp(r'\s+'), ' ');
    if (name.isEmpty) return 'Oyuncu';
    return name.length > 18 ? name.substring(0, 18) : name;
  }
}
