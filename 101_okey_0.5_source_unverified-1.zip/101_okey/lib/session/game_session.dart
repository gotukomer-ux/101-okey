import 'dart:async';

import '../game/game_state.dart';

/// Common contract consumed by the game table, whether the opponent seats are
/// remote humans or local computer players.
abstract interface class GameSession {
  Stream<GameView> get gameViews;
  Stream<String> get statuses;
  GameView? get currentGameView;
  bool get canStartNextRound;
  Future<void> submitGameAction(Map<String, dynamic> action);
  Future<void> startNextRound();
  Future<void> leave();
  Future<void> dispose();
}
