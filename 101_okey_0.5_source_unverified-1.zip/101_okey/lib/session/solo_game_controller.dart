import 'dart:async';
import 'dart:math';

import '../bot/bot_strategy.dart';
import '../game/game_engine.dart';
import '../game/game_state.dart';
import 'game_session.dart';

/// Offline session: one human on seat 0 and three local bots on seats 1–3.
/// All bot actions still pass through the same GameEngine rules as a network
/// player's actions.
class SoloGameController implements GameSession {
  SoloGameController._({
    required GameEngine engine,
    required List<BotStrategy> strategies,
    required this.botDelay,
  })  : _engine = engine,
        _strategies = strategies,
        _currentView = engine.viewFor(0);

  factory SoloGameController.newGame({
    String playerName = 'Sen',
    BotDifficulty difficulty = BotDifficulty.medium,
    Random? random,
    Duration botDelay = const Duration(milliseconds: 280),
  }) {
    final engine = GameEngine.start(
      playerNames: [playerName, 'Bot 1', 'Bot 2', 'Bot 3'],
      playerIds: const ['human-local', 'bot-local-1', 'bot-local-2', 'bot-local-3'],
      startingSeat: 0,
      random: random,
    );
    // The selected level applies to all three computer opponents. The names
    // are deliberately neutral; difficulty is shown in the game setup dialog.
    final strategy = BotStrategy(difficulty: difficulty);
    return SoloGameController._(
      engine: engine,
      strategies: [strategy, strategy, strategy],
      botDelay: botDelay,
    );
  }

  GameEngine _engine;
  final List<BotStrategy> _strategies;
  final Duration botDelay;
  final StreamController<GameView> _updates = StreamController<GameView>.broadcast();
  final StreamController<String> _statusUpdates = StreamController<String>.broadcast();
  GameView _currentView;
  bool _processingBots = false;
  bool _disposed = false;

  @override
  Stream<GameView> get gameViews => _updates.stream;

  @override
  Stream<String> get statuses => _statusUpdates.stream;

  @override
  GameView get currentGameView => _currentView;

  @override
  bool get canStartNextRound => _engine.isFinished;

  @override
  Future<void> submitGameAction(Map<String, dynamic> action) async {
    if (_disposed) throw StateError('Oyun oturumu kapalı.');
    if (_engine.isFinished) throw StateError('El tamamlandı.');
    if (_engine.currentSeat != 0) throw StateError('Şu anda sizin sıranız değil.');
    _engine.applyAction(0, action);
    _publish();
    if (!_engine.isFinished && _engine.currentSeat != 0) await _playBots();
  }

  Future<void> _playBots() async {
    if (_processingBots) return;
    _processingBots = true;
    try {
      var consecutiveBotTurns = 0;
      while (!_engine.isFinished && _engine.currentSeat != 0) {
        final seat = _engine.currentSeat;
        consecutiveBotTurns++;
        if (consecutiveBotTurns > 3) {
          throw StateError('Bot sırası ilerlemedi; oyun motoru kilitlenmiş olabilir.');
        }
        var actionCount = 0;
        while (!_engine.isFinished && _engine.currentSeat == seat) {
          if (actionCount++ >= 32) {
            throw StateError('Bot tek turda izin verilen hamle sayısını aştı.');
          }
          final view = _engine.viewFor(seat);
          final action = _strategies[seat - 1].nextAction(view);
          _engine.applyAction(seat, action);
          _publish();
          if (botDelay > Duration.zero && !_engine.isFinished) {
            await Future<void>.delayed(botDelay);
          }
        }
      }
    } finally {
      _processingBots = false;
    }
  }

  @override
  Future<void> startNextRound() async {
    if (_disposed) throw StateError('Oyun oturumu kapalı.');
    if (!_engine.isFinished) throw StateError('Yeni el için mevcut el tamamlanmalı.');
    final previous = _engine.viewFor(0);
    final players = [...previous.players]..sort((a, b) => a.seat.compareTo(b.seat));
    final scores = {for (final player in players) player.id: player.totalScore};
    _engine = GameEngine.start(
      playerNames: players.map((player) => player.name).toList(),
      playerIds: players.map((player) => player.id).toList(),
      roundNumber: _engine.roundNumber + 1,
      startingSeat: 0,
      initialScores: scores,
    );
    _publish();
  }

  void _publish() {
    _currentView = _engine.viewFor(0);
    if (!_updates.isClosed) _updates.add(_currentView);
  }

  @override
  Future<void> leave() async {
    // No transport exists for an offline session. The widget simply returns
    // to the home screen; disposal closes the stream.
  }

  @override
  Future<void> dispose() async {
    if (_disposed) return;
    _disposed = true;
    await _updates.close();
    await _statusUpdates.close();
  }
}
