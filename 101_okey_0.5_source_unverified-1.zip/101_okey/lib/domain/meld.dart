import 'tile.dart';

class MeldTile {
  const MeldTile(this.tile, {this.representedFace});
  final Tile tile;

  /// Required only when [tile] is the real okey. False jokers have a fixed face.
  final TileFace? representedFace;
}

enum MeldType { run, group }

class MeldValidation {
  const MeldValidation._(this.isValid, this.type, this.error);
  const MeldValidation.valid(MeldType type) : this._(true, type, null);
  const MeldValidation.invalid(String error) : this._(false, null, error);

  final bool isValid;
  final MeldType? type;
  final String? error;
}

class MeldValidator {
  static MeldValidation validate(List<MeldTile> items, TileFace realOkey) {
    if (items.length < 3) return const MeldValidation.invalid('A meld needs at least 3 tiles.');
    final ids = items.map((item) => item.tile.id).toSet();
    if (ids.length != items.length) return const MeldValidation.invalid('A physical tile cannot be used twice.');

    final faces = <TileFace>[];
    for (final item in items) {
      final tile = item.tile;
      if (tile.kind == TileKind.falseJoker) {
        if (item.representedFace != null) {
          return const MeldValidation.invalid('A false joker has a fixed face and cannot be reassigned.');
        }
        faces.add(realOkey);
        continue;
      }

      final printedFace = TileFace(tile.color!, tile.number!);
      if (item.representedFace != null) {
        if (printedFace != realOkey) {
          return const MeldValidation.invalid('Only a real okey tile may be assigned a substitute face.');
        }
        faces.add(item.representedFace!);
      } else {
        faces.add(printedFace);
      }
    }

    if (_isRun(faces)) return const MeldValidation.valid(MeldType.run);
    if (_isGroup(faces)) return const MeldValidation.valid(MeldType.group);
    return const MeldValidation.invalid('Tiles do not form a valid run or group.');
  }

  static bool _isRun(List<TileFace> faces) {
    if (faces.map((face) => face.color).toSet().length != 1) return false;
    final sorted = [...faces]..sort((a, b) => a.number.compareTo(b.number));
    for (var i = 1; i < sorted.length; i++) {
      if (sorted[i].number != sorted[i - 1].number + 1) return false;
    }
    // 13-1 wraparound is intentionally not accepted.
    if (sorted.first.number < 1 || sorted.last.number > 13) return false;
    return true;
  }

  static bool _isGroup(List<TileFace> faces) {
    if (faces.length > 4) return false;
    if (faces.map((face) => face.number).toSet().length != 1) return false;
    return faces.map((face) => face.color).toSet().length == faces.length;
  }
}
