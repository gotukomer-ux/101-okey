import '../domain/meld.dart';
import '../domain/tile.dart';
import '../domain/tile_set.dart';

enum OpeningType { normal, pairs }

enum GameMeldType { run, group, pair }

enum WinType { normal, okey, pairs, hand }

class GameMeld {
  const GameMeld({
    required this.id,
    required this.ownerSeat,
    required this.type,
    required this.tiles,
  });

  final String id;
  final int ownerSeat;
  final GameMeldType type;
  final List<MeldTile> tiles;

  Map<String, dynamic> toJson() => {
        'id': id,
        'ownerSeat': ownerSeat,
        'type': type.name,
        'tiles': tiles
            .map((item) => {
                  'tile': item.tile.toJson(),
                  'representedFace': item.representedFace?.toJson(),
                })
            .toList(),
      };

  factory GameMeld.fromJson(Map<String, dynamic> json) {
    final rawTiles = json['tiles'];
    final typeName = json['type'];
    final ownerSeat = json['ownerSeat'];
    final id = json['id'];
    if (rawTiles is! List || typeName is! String || ownerSeat is! int || id is! String) {
      throw const FormatException('Masa per bilgisi geçersiz.');
    }
    final type = GameMeldType.values.where((value) => value.name == typeName).firstOrNull;
    if (type == null || ownerSeat < 0 || ownerSeat > 3 || id.isEmpty) {
      throw const FormatException('Masa per türü veya sahibi geçersiz.');
    }
    final tiles = rawTiles.map((raw) {
      if (raw is! Map) throw const FormatException('Per taşı geçersiz.');
      final item = Map<String, dynamic>.from(raw);
      final rawTile = item['tile'];
      final rawFace = item['representedFace'];
      if (rawTile is! Map) throw const FormatException('Per taşı bulunamadı.');
      if (rawFace != null && rawFace is! Map) {
        throw const FormatException('Per içindeki joker temsil yüzü geçersiz.');
      }
      return MeldTile(
        Tile.fromJson(Map<String, dynamic>.from(rawTile)),
        representedFace: rawFace is Map
            ? TileFace.fromJson(Map<String, dynamic>.from(rawFace))
            : null,
      );
    }).toList();
    if (tiles.length < 2 || (type != GameMeldType.pair && tiles.length < 3) ||
        (type == GameMeldType.pair && tiles.length != 2)) {
      throw const FormatException('Masa perindeki taş sayısı geçersiz.');
    }
    return GameMeld(id: id, ownerSeat: ownerSeat, type: type, tiles: tiles);
  }
}

class PlayerGameSummary {
  const PlayerGameSummary({
    required this.id,
    required this.name,
    required this.seat,
    required this.handCount,
    required this.hasOpened,
    required this.openingType,
    required this.totalScore,
  });

  final String id;
  final String name;
  final int seat;
  final int handCount;
  final bool hasOpened;
  final OpeningType? openingType;
  final int totalScore;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'seat': seat,
        'handCount': handCount,
        'hasOpened': hasOpened,
        'openingType': openingType?.name,
        'totalScore': totalScore,
      };

  factory PlayerGameSummary.fromJson(Map<String, dynamic> json) {
    final openingName = json['openingType'];
    final opening = openingName is String
        ? OpeningType.values.where((value) => value.name == openingName).firstOrNull
        : null;
    if (openingName != null && opening == null) {
      throw const FormatException('Oyuncunun açılış türü geçersiz.');
    }
    final player = PlayerGameSummary(
      id: json['id'] as String,
      name: json['name'] as String,
      seat: json['seat'] as int,
      handCount: json['handCount'] as int,
      hasOpened: json['hasOpened'] as bool,
      openingType: opening,
      totalScore: json['totalScore'] as int? ?? 0,
    );
    if (player.id.isEmpty || player.name.trim().isEmpty ||
        player.seat < 0 || player.seat > 3 || player.handCount < 0 ||
        (player.hasOpened != (player.openingType != null))) {
      throw const FormatException('Oyuncu özeti tutarsız.');
    }
    return player;
  }
}

/// A seat-specific view. Only [myHand] is sent; opponents' tiles never leave the host.
class GameView {
  const GameView({
    required this.gameId,
    required this.roundNumber,
    required this.mySeat,
    required this.currentSeat,
    required this.indicator,
    required this.realOkey,
    required this.myHand,
    required this.discardPile,
    required this.drawPileCount,
    required this.players,
    required this.melds,
    required this.mustDraw,
    required this.requiredOpeningTileId,
    required this.roundFinished,
    required this.winnerSeat,
    required this.winType,
    required this.scoreDeltas,
  });

  final String gameId;
  final int roundNumber;
  final int mySeat;
  final int currentSeat;
  final Tile indicator;
  final TileFace realOkey;
  final List<Tile> myHand;
  final List<Tile> discardPile;
  final int drawPileCount;
  final List<PlayerGameSummary> players;
  final List<GameMeld> melds;
  final bool mustDraw;
  /// If a not-yet-opened player took the previous discard, this physical tile
  /// must be included in their opening during the current turn.
  final String? requiredOpeningTileId;
  final bool roundFinished;
  final int? winnerSeat;
  final WinType? winType;
  final Map<int, int> scoreDeltas;

  Map<String, dynamic> toJson() => {
        'gameId': gameId,
        'roundNumber': roundNumber,
        'mySeat': mySeat,
        'currentSeat': currentSeat,
        'indicator': indicator.toJson(),
        'realOkey': realOkey.toJson(),
        'myHand': myHand.map((tile) => tile.toJson()).toList(),
        'discardPile': discardPile.map((tile) => tile.toJson()).toList(),
        'drawPileCount': drawPileCount,
        'players': players.map((player) => player.toJson()).toList(),
        'melds': melds.map((meld) => meld.toJson()).toList(),
        'mustDraw': mustDraw,
        'requiredOpeningTileId': requiredOpeningTileId,
        'roundFinished': roundFinished,
        'winnerSeat': winnerSeat,
        'winType': winType?.name,
        'scoreDeltas': scoreDeltas.map((key, value) => MapEntry(key.toString(), value)),
      };

  factory GameView.fromJson(Map<String, dynamic> json) {
    List<Tile> parseTiles(Object? value, String field) {
      if (value is! List) throw FormatException('$field listesi geçersiz.');
      return value.map((raw) {
        if (raw is! Map) throw FormatException('$field içinde taş geçersiz.');
        return Tile.fromJson(Map<String, dynamic>.from(raw));
      }).toList();
    }

    final rawIndicator = json['indicator'];
    final rawOkey = json['realOkey'];
    final rawPlayers = json['players'];
    final rawMelds = json['melds'];
    final rawScores = json['scoreDeltas'];
    if (rawIndicator is! Map || rawOkey is! Map || rawPlayers is! List ||
        rawMelds is! List || rawScores is! Map) {
      throw const FormatException('Oyun görüntüsü eksik veya hatalı.');
    }
    final rawRequiredOpeningTileId = json['requiredOpeningTileId'];
    if (rawRequiredOpeningTileId != null && rawRequiredOpeningTileId is! String) {
      throw const FormatException('Yandan alınan zorunlu açılış taşı kimliği geçersiz.');
    }
    final rawWinType = json['winType'];
    final parsedWinType = rawWinType is String
        ? WinType.values.where((value) => value.name == rawWinType).firstOrNull
        : null;
    if (rawWinType != null && parsedWinType == null) {
      throw const FormatException('Bitiş türü geçersiz.');
    }
    final scores = <int, int>{};
    rawScores.forEach((key, value) {
      final seat = int.tryParse(key.toString());
      if (seat == null || value is! int || seat < 0 || seat > 3) {
        throw const FormatException('Puan dökümü geçersiz.');
      }
      scores[seat] = value;
    });
    final parsedPlayers = rawPlayers.map((raw) {
      if (raw is! Map) throw const FormatException('Oyuncu durumu geçersiz.');
      return PlayerGameSummary.fromJson(Map<String, dynamic>.from(raw));
    }).toList()..sort((a, b) => a.seat.compareTo(b.seat));
    final parsedMelds = rawMelds.map((raw) {
      if (raw is! Map) throw const FormatException('Masa per verisi geçersiz.');
      return GameMeld.fromJson(Map<String, dynamic>.from(raw));
    }).toList();
    final view = GameView(
      gameId: json['gameId'] as String,
      roundNumber: json['roundNumber'] as int,
      mySeat: json['mySeat'] as int,
      currentSeat: json['currentSeat'] as int,
      indicator: Tile.fromJson(Map<String, dynamic>.from(rawIndicator)),
      realOkey: TileFace.fromJson(Map<String, dynamic>.from(rawOkey)),
      myHand: parseTiles(json['myHand'], 'myHand'),
      discardPile: parseTiles(json['discardPile'], 'discardPile'),
      drawPileCount: json['drawPileCount'] as int,
      players: parsedPlayers,
      melds: parsedMelds,
      mustDraw: json['mustDraw'] as bool,
      requiredOpeningTileId: rawRequiredOpeningTileId as String?,
      roundFinished: json['roundFinished'] as bool,
      winnerSeat: json['winnerSeat'] as int?,
      winType: parsedWinType,
      scoreDeltas: scores,
    );
    final seats = view.players.map((player) => player.seat).toSet();
    final playerIds = view.players.map((player) => player.id).toSet();
    if (view.mySeat < 0 || view.mySeat > 3 || view.currentSeat < 0 ||
        view.currentSeat > 3 || view.players.length != 4 || seats.length != 4 ||
        !seats.containsAll(const [0, 1, 2, 3]) || playerIds.length != 4 ||
        view.gameId.isEmpty || view.roundNumber < 1 || view.drawPileCount < 0 ||
        view.players.firstWhere((player) => player.seat == view.mySeat).handCount != view.myHand.length ||
        (view.mustDraw && view.currentSeat != view.mySeat) ||
        (view.requiredOpeningTileId != null &&
            (view.requiredOpeningTileId!.isEmpty ||
             view.currentSeat != view.mySeat || view.mustDraw ||
             view.players.firstWhere((player) => player.seat == view.mySeat).hasOpened ||
             !view.myHand.any((tile) => tile.id == view.requiredOpeningTileId))) ||
        (view.roundFinished && view.mustDraw)) {
      throw const FormatException('Oyun görüntüsünde koltuk, el veya deste sayısı tutarsız.');
    }
    if (view.roundFinished != (view.winnerSeat != null) ||
        (view.winnerSeat != null && (view.winnerSeat! < 0 || view.winnerSeat! > 3)) ||
        (view.roundFinished && (view.winType == null || view.scoreDeltas.length != 4))) {
      throw const FormatException('El bitiş veya puan bilgisi tutarsız.');
    }
    final expectedOkey = TileSet.realOkeyFor(view.indicator);
    if (expectedOkey != view.realOkey) {
      throw const FormatException('Gösterge ile gerçek okey değeri uyuşmuyor.');
    }
    final meldIds = view.melds.map((meld) => meld.id).toSet();
    if (meldIds.length != view.melds.length) {
      throw const FormatException('Masa üzerinde yinelenen per kimliği var.');
    }
    final visibleIds = <String>{};
    void addVisible(Tile tile) {
      if (!visibleIds.add(tile.id)) {
        throw const FormatException('Aynı fiziksel taş oyun görüntüsünde birden fazla yerde.');
      }
    }
    addVisible(view.indicator);
    for (final tile in view.myHand) { addVisible(tile); }
    for (final tile in view.discardPile) { addVisible(tile); }
    for (final meld in view.melds) {
      final owner = view.players.where((player) => player.seat == meld.ownerSeat).firstOrNull;
      if (owner == null || !owner.hasOpened ||
          (meld.type == GameMeldType.pair && owner.openingType != OpeningType.pairs) ||
          (meld.type != GameMeldType.pair && owner.openingType != OpeningType.normal)) {
        throw const FormatException('Masa perinin sahibi veya açılış türü uyuşmuyor.');
      }
      final validation = MeldValidator.validate(meld.tiles, view.realOkey);
      if (meld.type == GameMeldType.pair) {
        final pair = meld.tiles;
        if (pair.length != 2 || !pair[0].tile.isNumbered || !pair[1].tile.isNumbered ||
            pair[0].tile.color != pair[1].tile.color || pair[0].tile.number != pair[1].tile.number) {
          throw const FormatException('Masa üzerindeki çift geçersiz.');
        }
      } else if (!validation.isValid ||
          (meld.type == GameMeldType.run && validation.type != MeldType.run) ||
          (meld.type == GameMeldType.group && validation.type != MeldType.group)) {
        throw const FormatException('Masa üzerindeki per geçersiz.');
      }
      for (final item in meld.tiles) { addVisible(item.tile); }
    }
    return view;
  }
}
