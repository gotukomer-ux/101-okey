import 'dart:math';

import 'package:flutter_test/flutter_test.dart';
import 'package:classic_101_okey/domain/tile.dart';
import 'package:classic_101_okey/game/game_engine.dart';
import 'package:classic_101_okey/game/game_state.dart';

Tile t(String id, TileColor color, int number) =>
    Tile.numbered(id: id, color: color, number: number);

final indicator = t('indicator', TileColor.yellow, 4);
const realOkey = TileFace(TileColor.yellow, 5);

List<List<Tile>> normalOpeningHands() => [
      [
        t('r1', TileColor.red, 1),
        t('r2', TileColor.red, 2),
        t('r3', TileColor.red, 3),
        t('b5', TileColor.blue, 5),
        t('b6', TileColor.blue, 6),
        t('b7', TileColor.blue, 7),
        t('k8', TileColor.black, 8),
        t('k9', TileColor.black, 9),
        t('k10', TileColor.black, 10),
        t('y10', TileColor.yellow, 10),
        t('y11', TileColor.yellow, 11),
        t('y12', TileColor.yellow, 12),
        t('y13', TileColor.yellow, 13),
        t('r7', TileColor.red, 7),
        t('b7g', TileColor.blue, 7),
        t('k7g', TileColor.black, 7),
        t('r4', TileColor.red, 4),
        t('spare', TileColor.blue, 1),
      ],
      [t('p1', TileColor.red, 1)],
      [t('p2', TileColor.blue, 2)],
      [t('p3', TileColor.black, 3)],
    ];

List<List<MeldTile>> normalMelds(List<Tile> hand) {
  final byId = {for (final tile in hand) tile.id: tile};
  return [
    ['r1', 'r2', 'r3'],
    ['b5', 'b6', 'b7'],
    ['k8', 'k9', 'k10'],
    ['y10', 'y11', 'y12', 'y13'],
    ['r7', 'b7g', 'k7g'],
  ].map((ids) => ids.map((id) => MeldTile(byId[id]!)).toList()).toList();
}

GameEngine normalEngine() => GameEngine.forTesting(
      indicator: indicator,
      realOkey: realOkey,
      hands: normalOpeningHands(),
      drawPile: [t('draw1', TileColor.black, 1), t('draw2', TileColor.black, 2)],
    );

void main() {
  group('GameEngine', () {
    test('new round can seed cumulative scores without resetting standings', () {
      final game = GameEngine.start(
        playerNames: const ['A', 'B', 'C', 'D'],
        playerIds: const ['seat-a', 'seat-b', 'seat-c', 'seat-d'],
        roundNumber: 2,
        startingSeat: 1,
        initialScores: const {'seat-a': -101, 'seat-b': 202, 'seat-c': 17, 'seat-d': 0},
        random: Random(123),
      );
      expect(game.viewFor(0).roundNumber, 2);
      expect(game.handFor(1), hasLength(22));
      expect(game.viewFor(0).players.firstWhere((p) => p.id == 'seat-a').totalScore, -101);
      expect(game.viewFor(0).players.firstWhere((p) => p.id == 'seat-b').totalScore, 202);
    });

    test('starts a four-player deal with the correct hand and stock counts', () {
      final game = GameEngine.start(
        playerNames: const ['A', 'B', 'C', 'D'],
        random: Random(17),
      );
      expect(game.handFor(0), hasLength(22));
      expect(game.handFor(1), hasLength(21));
      expect(game.handFor(2), hasLength(21));
      expect(game.handFor(3), hasLength(21));
      expect(game.drawPileCount, 20);
    });

    test('rejects actions from a player whose turn has not arrived', () {
      final game = normalEngine();
      expect(() => game.drawFromStock(1), throwsStateError);
      expect(() => game.discard(1, 'p1'), throwsStateError);
    });

    test('advances turns only after discard and then requires a draw', () {
      final game = normalEngine();
      game.discard(0, 'spare');
      expect(game.currentSeat, 1);
      expect(game.mustDraw, isTrue);
      expect(game.handFor(0), hasLength(17));
      game.drawFromStock(1);
      expect(game.mustDraw, isFalse);
      expect(game.handFor(1), hasLength(2));
      expect(game.drawPileCount, 1);
    });

    test('yandan alınan taş açılmamış oyuncunun aynı tur açılışında kullanılmalıdır', () {
      final game = normalEngine();
      game.discard(0, 'spare');
      game.takeDiscard(1);
      expect(() => game.discard(1, 'spare'), throwsStateError);
    });


    test('only the player who takes a discard receives the required opening tile ID', () {
      final game = GameEngine.forTesting(
        indicator: indicator,
        realOkey: realOkey,
        hands: [
          [t('h0', TileColor.red, 1)],
          [t('h1', TileColor.blue, 2)],
          [t('h2', TileColor.black, 3)],
          [t('h3', TileColor.yellow, 4)],
        ],
        discardPile: [t('table-top', TileColor.red, 5)],
        currentSeat: 1,
        mustDraw: true,
      );
      game.takeDiscard(1);
      final currentPlayerView = game.viewFor(1);
      final otherPlayerView = game.viewFor(2);
      expect(currentPlayerView.requiredOpeningTileId, 'table-top');
      expect(otherPlayerView.requiredOpeningTileId, isNull);
      final restored = GameView.fromJson(currentPlayerView.toJson());
      expect(restored.requiredOpeningTileId, 'table-top');
    });

    test('rejects a normal opening below 101 points', () {
      final game = normalEngine();
      final hand = game.handFor(0);
      final byId = {for (final tile in hand) tile.id: tile};
      expect(
        () => game.openNormally(0, [
          ['r1', 'r2', 'r3'].map((id) => MeldTile(byId[id]!)).toList(),
        ]),
        throwsStateError,
      );
    });

    test('opens at 101+, adds a valid tile to an existing run, and finishes by discard', () {
      final game = normalEngine();
      game.openNormally(0, normalMelds(game.handFor(0)));
      expect(game.viewFor(0).players.firstWhere((player) => player.seat == 0).hasOpened, isTrue);
      expect(game.viewFor(0).myHand.map((tile) => tile.id).toSet(), {'r4', 'spare'});

      game.addToMeld(0, 'meld-1', MeldTile(t('r4', TileColor.red, 4)));
      expect(game.handFor(0).map((tile) => tile.id), ['spare']);
      game.discard(0, 'spare');
      expect(game.isFinished, isTrue);
      expect(game.viewFor(0).winnerSeat, 0);
      expect(game.viewFor(0).winType, WinType.hand);
      expect(game.viewFor(0).scoreDeltas[0], -202);
      expect(game.viewFor(0).scoreDeltas[1], 404);
    });

    test('rejects an invalid tile processed into a run without changing the hand', () {
      final game = normalEngine();
      game.openNormally(0, normalMelds(game.handFor(0)));
      expect(
        () => game.addToMeld(0, 'meld-1', MeldTile(t('spare', TileColor.blue, 1))),
        throwsStateError,
      );
      expect(game.handFor(0).map((tile) => tile.id).toSet(), {'r4', 'spare'});
    });

    test('a client view includes only that seat hand, not opponent hands', () {
      final game = normalEngine();
      final view = game.viewFor(1);
      expect(view.mySeat, 1);
      expect(view.myHand.map((tile) => tile.id), ['p1']);
      final json = view.toJson();
      expect(json.containsKey('opponentHands'), isFalse);
      expect(json['myHand'], hasLength(1));
      expect((json['players'] as List).every((player) => !player.containsKey('hand')), isTrue);
    });

    test('view survives JSON round trip', () {
      final game = normalEngine();
      final view = GameView.fromJson(game.viewFor(2).toJson());
      expect(view.mySeat, 2);
      expect(view.currentSeat, 0);
      expect(view.players, hasLength(4));
      expect(view.myHand.single.id, 'p2');
    });


    test('rejects malformed network actions without mutating the game', () {
      final game = normalEngine();
      expect(() => game.applyAction(0, {'action': 'not_an_action'}), throwsFormatException);
      expect(() => game.applyAction(0, {'action': 'discard', 'tileId': 999}), throwsFormatException);
      expect(game.handFor(0), hasLength(18));
      expect(game.currentSeat, 0);
    });

    test('rejects an okey substitute with a malformed represented face payload', () {
      final game = normalEngine();
      expect(
        () => game.applyAction(0, {
          'action': 'open_normal',
          'melds': [
            [
              {'tileId': 'r1'},
              {'tileId': 'r2', 'representedFace': 'not-a-face'},
              {'tileId': 'r3'},
            ],
          ],
        }),
        throwsFormatException,
      );
      expect(game.handFor(0), hasLength(18));
    });


    test('game view rejects duplicate physical tiles across private hand and public zones', () {
      final game = normalEngine();
      final json = game.viewFor(1).toJson();
      json['myHand'] = [game.indicator.toJson()];
      expect(() => GameView.fromJson(json), throwsFormatException);
    });

    test('game view rejects indicator and real okey mismatch', () {
      final game = normalEngine();
      final json = game.viewFor(1).toJson();
      json['realOkey'] = const TileFace(TileColor.red, 9).toJson();
      expect(() => GameView.fromJson(json), throwsFormatException);
    });

    test('false joker scores its represented face value and round totals are accumulated', () {
      final opener = <Tile>[
        t('rr1', TileColor.red, 1), t('rr2', TileColor.red, 2), t('rr3', TileColor.red, 3),
        t('bb5', TileColor.blue, 5), t('bb6', TileColor.blue, 6), t('bb7', TileColor.blue, 7),
        t('kk8', TileColor.black, 8), t('kk9', TileColor.black, 9), t('kk10', TileColor.black, 10),
        t('yy10', TileColor.yellow, 10), t('yy11', TileColor.yellow, 11),
        t('yy12', TileColor.yellow, 12), t('yy13', TileColor.yellow, 13),
        t('rr7', TileColor.red, 7), t('bb7g', TileColor.blue, 7), t('kk7g', TileColor.black, 7),
        const Tile.falseJoker(id: 'false-left'), t('opener-discard', TileColor.blue, 1),
      ];
      final hands = [
        <Tile>[],
        opener,
        [t('seat2-left', TileColor.red, 8)],
        [t('seat3-left', TileColor.blue, 9)],
      ];
      // drawFromStock removes from the end, so the first active player gets
      // the final element of this deterministic test pile.
      final stock = [
        t('stock-winner', TileColor.yellow, 3),
        t('stock-seat3', TileColor.yellow, 2),
        t('stock-seat2', TileColor.yellow, 1),
      ];
      final game = GameEngine.forTesting(
        indicator: indicator,
        realOkey: realOkey,
        hands: hands,
        drawPile: stock,
        currentSeat: 1,
      );
      final byId = {for (final tile in opener) tile.id: tile};
      game.openNormally(1, [
        ['rr1', 'rr2', 'rr3'].map((id) => MeldTile(byId[id]!)).toList(),
        ['bb5', 'bb6', 'bb7'].map((id) => MeldTile(byId[id]!)).toList(),
        ['kk8', 'kk9', 'kk10'].map((id) => MeldTile(byId[id]!)).toList(),
        ['yy10', 'yy11', 'yy12', 'yy13'].map((id) => MeldTile(byId[id]!)).toList(),
        ['rr7', 'bb7g', 'kk7g'].map((id) => MeldTile(byId[id]!)).toList(),
      ]);
      game.discard(1, 'opener-discard');
      game.drawFromStock(2);
      game.discard(2, 'seat2-left');
      game.drawFromStock(3);
      game.discard(3, 'seat3-left');
      game.drawFromStock(0);
      game.discard(0, 'stock-winner');

      expect(game.viewFor(0).winType, WinType.normal);
      expect(game.viewFor(0).scoreDeltas[1], 5);
      expect(game.viewFor(0).players.firstWhere((p) => p.seat == 1).totalScore, 5);
      expect(game.viewFor(0).players.firstWhere((p) => p.seat == 0).totalScore, -101);
    });

    test('pair opening requires five distinct valid pairs and leaves a discard', () {
      final pairs = <Tile>[];
      for (var number = 1; number <= 5; number++) {
        pairs
          ..add(t('pair-$number-a', TileColor.red, number))
          ..add(t('pair-$number-b', TileColor.red, number));
      }
      final game = GameEngine.forTesting(
        indicator: indicator,
        realOkey: realOkey,
        hands: [
          [...pairs, t('last', TileColor.blue, 9)],
          [t('a1', TileColor.black, 1)],
          [t('a2', TileColor.black, 2)],
          [t('a3', TileColor.black, 3)],
        ],
      );
      game.openPairs(0, [
        for (var number = 1; number <= 5; number++)
          ['pair-$number-a', 'pair-$number-b'],
      ]);
      expect(game.viewFor(0).myHand.single.id, 'last');
      game.discard(0, 'last');
      expect(game.viewFor(0).winType, WinType.pairs);
      expect(game.viewFor(0).scoreDeltas[0], -202);
    });
  });
}

