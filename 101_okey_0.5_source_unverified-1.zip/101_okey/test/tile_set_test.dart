import 'dart:math';
import 'package:flutter_test/flutter_test.dart';
import 'package:classic_101_okey/domain/tile.dart';
import 'package:classic_101_okey/domain/tile_set.dart';

void main() {
  test('creates exactly 106 physical tiles with unique ids', () {
    final tiles = TileSet.create();
    expect(tiles, hasLength(106));
    expect(tiles.map((tile) => tile.id).toSet(), hasLength(106));
    expect(tiles.where((tile) => tile.isNumbered), hasLength(104));
    expect(tiles.where((tile) => !tile.isNumbered), hasLength(2));
  });

  test('deals 22 to starter, 21 to others, indicator and 20 in stock', () {
    final deal = TileSet.deal(random: Random(7), startingPlayer: 2);
    expect(deal.hands.map((hand) => hand.length).toList(), [21, 21, 22, 21]);
    expect(deal.drawPile, hasLength(20));
    final allIds = <String>{deal.indicator.id};
    for (final hand in deal.hands) {
      for (final tile in hand) {
        expect(allIds.add(tile.id), isTrue);
      }
    }
    for (final tile in deal.drawPile) {
      expect(allIds.add(tile.id), isTrue);
    }
    expect(allIds, hasLength(106));
  });

  test('indicator 13 wraps real okey to 1 in the same colour', () {
    const indicator = Tile.numbered(id: 'indicator-13', color: TileColor.red, number: 13);
    expect(TileSet.realOkeyFor(indicator), const TileFace(TileColor.red, 1));
  });

  test('numbered indicator advances to next face in its colour', () {
    const indicator = Tile.numbered(id: 'indicator-6', color: TileColor.blue, number: 6);
    expect(TileSet.realOkeyFor(indicator), const TileFace(TileColor.blue, 7));
  });

  test('false joker cannot be used as the indicator', () {
    expect(
      () => TileSet.realOkeyFor(const Tile.falseJoker(id: 'false-indicator')),
      throwsArgumentError,
    );
  });
}
