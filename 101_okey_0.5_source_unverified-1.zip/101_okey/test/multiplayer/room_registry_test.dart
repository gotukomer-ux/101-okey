import 'package:flutter_test/flutter_test.dart';
import 'package:classic_101_okey/multiplayer/room_state.dart';

void main() {
  group('RoomRegistry', () {
    test('host plus three clients occupy exactly four unique seats', () {
      final room = RoomRegistry(hostId: 'host', hostName: 'Masa sahibi');
      expect(room.snapshot.occupiedSeats, 1);

      final first = room.join(playerId: 'p1', playerName: 'Ali', peerId: 'socket-1');
      final second = room.join(playerId: 'p2', playerName: 'Ayşe', peerId: 'socket-2');
      final third = room.join(playerId: 'p3', playerName: 'Mehmet', peerId: 'socket-3');

      expect(first.accepted, isTrue);
      expect(second.accepted, isTrue);
      expect(third.accepted, isTrue);
      expect(room.snapshot.occupiedSeats, 4);
      expect(room.snapshot.players.map((p) => p.seat).toSet(), {0, 1, 2, 3});
      expect(room.snapshot.isFull, isTrue);
    });

    test('fifth player is rejected and existing seats do not change', () {
      final room = RoomRegistry(hostId: 'host', hostName: 'Host');
      for (var i = 1; i <= 3; i++) {
        expect(room.join(playerId: 'p$i', playerName: 'P$i', peerId: 'peer-$i').accepted, isTrue);
      }
      final result = room.join(playerId: 'p4', playerName: 'P4', peerId: 'peer-4');
      expect(result.accepted, isFalse);
      expect(result.reason, 'Masa dolu.');
      expect(room.snapshot.occupiedSeats, 4);
    });

    test('duplicate player and duplicate connection are rejected', () {
      final room = RoomRegistry(hostId: 'host', hostName: 'Host');
      expect(room.join(playerId: 'p1', playerName: 'P1', peerId: 'peer-1').accepted, isTrue);
      expect(room.join(playerId: 'p1', playerName: 'P1 tekrar', peerId: 'peer-2').accepted, isFalse);
      expect(room.join(playerId: 'p2', playerName: 'P2', peerId: 'peer-1').accepted, isFalse);
    });

    test('disconnect frees the seat for another player', () {
      final room = RoomRegistry(hostId: 'host', hostName: 'Host');
      room.join(playerId: 'p1', playerName: 'P1', peerId: 'peer-1');
      expect(room.removePeer('peer-1'), isTrue);
      expect(room.snapshot.occupiedSeats, 1);
      final result = room.join(playerId: 'p2', playerName: 'P2', peerId: 'peer-2');
      expect(result.accepted, isTrue);
      expect(result.snapshot!.players.last.seat, 1);
    });

    test('room cannot start before four players join', () {
      final room = RoomRegistry(hostId: 'host', hostName: 'Host');
      expect(() => room.start(), throwsStateError);
      for (var i = 1; i <= 3; i++) {
        room.join(playerId: 'p$i', playerName: 'P$i', peerId: 'peer-$i');
      }
      expect(() => room.start(), returnsNormally);
      expect(room.snapshot.started, isTrue);
    });

    test('snapshot rejects duplicate or out-of-range seats', () {
      expect(
        () => RoomSnapshot.fromJson({
          'players': [
            {'id': 'host', 'name': 'Host', 'seat': 0, 'isHost': true},
            {'id': 'p1', 'name': 'P1', 'seat': 0, 'isHost': false},
          ],
          'started': false,
        }),
        throwsFormatException,
      );
      expect(
        () => RoomSnapshot.fromJson({
          'players': [
            {'id': 'host', 'name': 'Host', 'seat': 5, 'isHost': true},
          ],
          'started': false,
        }),
        throwsFormatException,
      );
    });

    test('snapshot survives JSON round trip', () {
      final room = RoomRegistry(hostId: 'host', hostName: 'Host');
      room.join(playerId: 'p1', playerName: 'Ali', peerId: 'peer-1');
      final restored = RoomSnapshot.fromJson(room.snapshot.toJson());
      expect(restored.players.map((p) => p.name), ['Host', 'Ali']);
      expect(restored.occupiedSeats, 2);
    });
  });
}
