import 'dart:async';

import 'package:flutter_test/flutter_test.dart';
import 'package:classic_101_okey/multiplayer/lan_transport.dart';
import 'package:classic_101_okey/multiplayer/transport_event.dart';

void main() {
  test('LAN transport exchanges newline-delimited JSON in both directions', () async {
    final host = LanTransport(port: 0);
    final hostMessage = Completer<TransportEvent>();
    final clientMessage = Completer<TransportEvent>();
    final peerConnected = Completer<String>();
    final hostSubscription = host.events.listen((event) {
      if (event.type == TransportEventType.connected &&
          event.peerId != null &&
          !peerConnected.isCompleted) {
        peerConnected.complete(event.peerId!);
      }
      if (event.type == TransportEventType.message && !hostMessage.isCompleted) {
        hostMessage.complete(event);
      }
    });

    LanTransport? client;
    StreamSubscription<TransportEvent>? clientSubscription;
    try {
      final address = await host.host();
      final port = int.parse(address.split(':').last);
      client = LanTransport(port: port);
      clientSubscription = client.events.listen((event) {
        if (event.type == TransportEventType.message && !clientMessage.isCompleted) {
          clientMessage.complete(event);
        }
      });

      await client.join('127.0.0.1');
      await client.send({'type': 'ping', 'value': 101});
      final inbound = await hostMessage.future.timeout(const Duration(seconds: 4));
      expect(inbound.data, {'type': 'ping', 'value': 101});

      final peerId = await peerConnected.future.timeout(const Duration(seconds: 4));
      await host.send({'type': 'pong', 'value': 'ready'}, peerId: peerId);
      final response = await clientMessage.future.timeout(const Duration(seconds: 4));
      expect(response.data, {'type': 'pong', 'value': 'ready'});
    } finally {
      await clientSubscription?.cancel();
      await hostSubscription.cancel();
      await client?.disposeTransport();
      await host.disposeTransport();
    }
  }, timeout: const Timeout(Duration(seconds: 12)));
}
