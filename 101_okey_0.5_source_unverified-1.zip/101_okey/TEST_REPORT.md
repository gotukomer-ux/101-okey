# 101 Okey — development test report

Date: 2026-11-14  
Source version: 0.5.0+5  
Status: **SOURCE CHECKS PASS; APP BUILD / RUNTIME NOT VERIFIED**

## Summary

This source milestone connects the offline bot mode and the local multiplayer mode to the same game engine. It adds a rule-based bot driver, cumulative scoring across rounds, host-authoritative action replication, per-seat private views, better validation for incoming views, mandatory-discard opening state, and clearer display of joker representations.

This is not a release approval. No APK was built, and no physical-device test was possible in the current environment.

## Checks actually executed

| Check | Result | Notes |
|---|---|---|
| Python source-structure checker | PASS — 44 checks | Checks file presence and key source contracts; does not execute Dart |
| Dart lexical scan | PASS — 26 files | Pygments lexer reported no lexical Error token; not a Dart compiler |
| `pubspec.yaml` parse | PASS | Parsed with PyYAML |
| Android manifest XML parse | PASS | Parsed with ElementTree |
| Shell script syntax | PASS | `bash -n scripts/bootstrap_android.sh scripts/verify_android.sh` |
| Flutter unit/integration tests | NOT RUN | `flutter` command not found |
| Dart formatter / analyzer | NOT RUN | Dart/Flutter SDK unavailable |
| Android APK build | NOT RUN | Flutter and Android SDK unavailable |
| Four-phone Wi-Fi test | NOT RUN | No physical Android devices available |
| Four-phone Bluetooth RFCOMM test | NOT RUN | Requires paired physical Android devices |

An explicit attempt to run `flutter test` and `flutter build apk --debug` returned `bash: flutter: command not found`.

## Added / expanded automated test cases (source only; not executed)

The test tree currently contains 9 test files and 50 `test(...)` declarations. Coverage includes:

- 106 physical tiles, unique IDs, dealing counts and indicator/okey behavior.
- Valid and invalid runs/groups and represented okey values.
- 101 opening and five-pair opening.
- Turn order, stock draw, discard pickup, forced use of a taken discard, meld addition, finish and score totals.
- Serialization of the private game view and validation of duplicate physical tiles / indicator consistency.
- Easy/medium/hard bot paths, normal and pair opening, meld extension, discard-pile choice and automatic three-bot turns.
- Four-seat room allocation, local TCP messaging, host-authoritative LAN game synchronization across multiple remote turns, and protocol-version rejection over a local TCP socket.

## Important unverified areas

- The added Dart source has not been compiled by the Dart compiler. Static checks and lexical scanning are not substitutes for `flutter analyze` or `flutter test`.
- Bluetooth Classic requires a real Android test with one host and three clients.
- Wi-Fi TCP requires a four-device test on a router that allows clients to communicate.
- Player reconnection after a game starts is not complete; a disconnected seat remains reserved for the current hand.
- Pair-table processing, stock exhaustion and the exact combination precedence for special finishes still require the chosen table-rule specification.

## Release gate

Do not label this source archive as a working app or distribute it as a verified APK until all Flutter commands and physical-device tests above pass.
